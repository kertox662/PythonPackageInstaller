import subprocess
import sys

#######################################
#Function to check pip install
#######################################
def checkPip():
    cmd = "py -3 -m pip" if sys.platform == 'win32' else "python3 -m pip" #This command will normally give options for 
                                  #arguments for the pip command but will output to stderr if the command is not found
    process = subprocess.Popen(cmd,
                               shell=True,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)

    for line in process.stderr:
        return False
    return True #Returns if whether it is installed or not

#######################################
#Function to check PIL install
#######################################
def checkPackage():
    try:
        import PIL
    except ImportError: #If the PIL package is not installed, this import will raise an ImportError
        return False
    return True #Returns if whether it is installed or not


#######################################
#Function to install pip
#######################################
def installPip(printOut = False):
    cmd = "py -3 resources\get-pip.py --user" if sys.platform == 'win32' else "python3 resources/get-pip.py --user" 
    #Runs the python script in resources and installs pip locally for the user
    process = subprocess.Popen(cmd,
                               shell=True,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)
    if not printOut: #Default Behaviour
        process.wait()
    else:
        while process.poll() is None: #Keeps printing stdout until the process is done
            for line in process.stdout:
                print("Out: {}".format(line.decode()), end = '')

    noError = True #Assumes no errors have occurred
    for line in process.stderr:
        print(line.decode(), end = '')
        noError = False #If there are any items from stderr, then an error has occurred

    if not noError:
        print("Something went wrong in installation, see information above.")
    return noError


#######################################
#Function to install PIL
#######################################
def installPackage(printOut = False):
    cmd = "py -3 -m pip install Pillow --user" if sys.platform == 'win32' else "python3 -m pip install Pillow --user" 
    #Runs the pip command to install the Pillow (PIL) package from online
    # cmd = "py -3 -m pip install resources\Pillow-4.3.0-cp33-cp33m-win32.whl --user" if sys.platform == 'win32' else "python3 -m pip install Pillow" #Runs the pip command for the wheel file in resources
    process = subprocess.Popen(cmd,
                               shell=True,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)

    if not printOut: #Default Behaviour
        process.wait()
    else:
        while process.poll() is None: #Keeps printing stdout until the process is done
            for line in process.stdout:
                print(line.decode(), end = '')

    noError = True #Assumes no errors have occurred
    for line in process.stderr:
        print("Err: {}".format(line.decode()), end = '')
        noError = False #If there are any items from stderr, then an error has occurred
    
    if not noError:
        print("Something went wrong in installation, see information above.")
    return noError